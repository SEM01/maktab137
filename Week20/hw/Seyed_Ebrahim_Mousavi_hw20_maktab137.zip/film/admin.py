from django.contrib import admin
from film.models import Director, Actor, Film


class FilmAdmin(admin.ModelAdmin):
    list_display = ("title", "genre", "release_year")
    search_fields = ["title"]
    list_filter = ["genre", "release_year"]


admin.site.register(Director)
admin.site.register(Film, FilmAdmin)
admin.site.register(Actor)

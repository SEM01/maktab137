from django.apps import AppConfig


class FilmConfig(AppConfig):
    name = 'film'

from django.db import models


class Director(models.Model):
    name = models.CharField(
        max_length=30, verbose_name="Name", help_text="Director's name"
    )
    age = models.IntegerField(verbose_name="Age", help_text="Director's age")
    bio = models.TextField(verbose_name="Biography", help_text="Director's Biography")

    def __str__(self):
        return f"{self.name}"


class Actor(models.Model):
    name = models.CharField(
        max_length=30, verbose_name="Name", help_text="Director's name"
    )
    age = models.IntegerField(verbose_name="Age", help_text="Director's age")
    bio = models.TextField(verbose_name="Biography", help_text="Director's Biography")

    def __str__(self):
        return f"{self.name}"


class Film(models.Model):
    title = models.CharField(
        max_length=50, verbose_name="Film Title", help_text="Title of the movie"
    )
    genre = models.CharField(
        max_length=20, verbose_name="Genre", help_text="Genre of the movie"
    )
    release_year = models.IntegerField(
        verbose_name="Release Year", help_text="production year"
    )
    duration = models.TimeField(verbose_name="Duration", help_text="Movie duration")
    poster = models.ImageField(upload_to="img/")
    description = models.TextField(
        verbose_name="Description", help_text="Movie description"
    )
    rate = models.FloatField(verbose_name="Rate", help_text="Movie rate")
    director = models.ForeignKey(
        Director, on_delete=models.CASCADE, related_name="movie_director"
    )
    actor = models.ManyToManyField(Actor, related_name="movie_actor")

    def __str__(self):
        return f"{self.title}"
    

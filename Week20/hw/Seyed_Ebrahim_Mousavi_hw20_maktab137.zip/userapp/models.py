from django.db import models


class UserApp(models.Model):
    username = models.CharField(
        max_length=15, verbose_name="UserName", help_text="User Name"
    )
    name = models.CharField(max_length=20, verbose_name="Name", help_text="User name")
    email = models.EmailField(verbose_name="Email", help_text="User Email")
    account_creation = models.DateTimeField(
        verbose_name="Account Creation Date", help_text="User Account Creation Date"
    )
    account_period = models.DateTimeField(
        verbose_name="Account Period", help_text="User Account Period Time"
    )

    def __str__(self):
        return f"{self.name}"

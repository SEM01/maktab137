from django.contrib import admin
from userapp.models import UserApp


admin.site.register(UserApp)

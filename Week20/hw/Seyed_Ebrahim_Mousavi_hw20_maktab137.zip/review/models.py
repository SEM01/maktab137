from django.db import models


class Review(models.Model):
    review = models.TextField(
        verbose_name="Review", help_text="Movie's Review from User"
    )
    film = models.ForeignKey(
        "film.Film", on_delete=models.CASCADE, related_name="film_review"
    )
    user = models.ForeignKey(
        "userapp.UserApp", on_delete=models.CASCADE, related_name="user_review"
    )

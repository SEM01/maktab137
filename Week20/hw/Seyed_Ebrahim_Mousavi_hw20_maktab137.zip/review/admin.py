from django.contrib import admin
from review.models import Review


admin.site.register(Review)
